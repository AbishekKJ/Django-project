from django.contrib import admin
from django.urls import path
from django.conf.urls import url, include
from django.contrib.auth.views import LoginView,LogoutView
from .views import home

urlpatterns = [
    url(r'$', home, name="Jobportal_home"),
    url(r'login$',LoginView.as_view(template_name="Jobportal/login_form.html"),name="Jobportal_login"),
    url(r'logout',LogoutView.as_view(),name="Jobportal_logout")
]
